from django.apps import AppConfig


class TimeIsMoneyAppConfig(AppConfig):
    name = 'time_is_money_app'
